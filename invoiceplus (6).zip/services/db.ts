
import { Invoice, Client, User, DashboardStats } from '../types';

const STORAGE_KEYS = {
  INVOICES: 'invoiceplus_invoices',
  CLIENTS: 'invoiceplus_clients',
  USER: 'invoiceplus_user',
  ALL_USERS: 'invoiceplus_registered_users',
  SESSION: 'invoiceplus_session_uid'
};

export const db = {
  // Local Session Management
  getSessionUid: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.SESSION);
  },

  setSessionUid: (uid: string | null) => {
    if (uid) localStorage.setItem(STORAGE_KEYS.SESSION, uid);
    else localStorage.removeItem(STORAGE_KEYS.SESSION);
  },

  // User Management
  getCurrentUserData: async (uid: string): Promise<User | null> => {
    const usersJson = localStorage.getItem(STORAGE_KEYS.ALL_USERS);
    const users = usersJson ? JSON.parse(usersJson) : {};
    return users[uid] || null;
  },

  updateUser: async (uid: string, updatedUser: Partial<User>) => {
    const usersJson = localStorage.getItem(STORAGE_KEYS.ALL_USERS);
    const users = usersJson ? JSON.parse(usersJson) : {};
    const existing = users[uid] || {};
    users[uid] = { ...existing, ...updatedUser };
    localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(users));
  },

  // Registry (for Mock Auth)
  registerUser: async (user: User): Promise<void> => {
    const usersJson = localStorage.getItem(STORAGE_KEYS.ALL_USERS);
    const users = usersJson ? JSON.parse(usersJson) : {};
    users[user.id] = user;
    localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(users));
  },

  validateUser: async (email: string, pass: string): Promise<User | null> => {
    const usersJson = localStorage.getItem(STORAGE_KEYS.ALL_USERS);
    const users = usersJson ? JSON.parse(usersJson) : {};
    const user = Object.values(users).find((u: any) => u.email === email) as User | undefined;
    // In local mode, we accept any login if registered
    return user || null;
  },

  // Invoice Management
  getInvoices: async (uid: string): Promise<Invoice[]> => {
    const data = localStorage.getItem(`${STORAGE_KEYS.INVOICES}_${uid}`);
    return data ? JSON.parse(data) : [];
  },

  saveInvoice: async (uid: string, invoice: Invoice) => {
    const invoices = await db.getInvoices(uid);
    const invoiceId = invoice.id || Math.random().toString(36).substr(2, 9);
    const finalInvoice = { ...invoice, id: invoiceId };
    
    const index = invoices.findIndex(i => i.id === invoiceId);
    if (index > -1) {
      invoices[index] = finalInvoice;
    } else {
      invoices.push(finalInvoice);
    }
    
    localStorage.setItem(`${STORAGE_KEYS.INVOICES}_${uid}`, JSON.stringify(invoices));
    return finalInvoice;
  },

  deleteInvoice: async (uid: string, invoiceId: string) => {
    const invoices = await db.getInvoices(uid);
    const filtered = invoices.filter(i => i.id !== invoiceId);
    localStorage.setItem(`${STORAGE_KEYS.INVOICES}_${uid}`, JSON.stringify(filtered));
  },

  // Client Management
  getClients: async (uid: string): Promise<Client[]> => {
    const data = localStorage.getItem(`${STORAGE_KEYS.CLIENTS}_${uid}`);
    return data ? JSON.parse(data) : [];
  },

  saveClient: async (uid: string, client: Client) => {
    const clients = await db.getClients(uid);
    const clientId = client.id || Math.random().toString(36).substr(2, 9);
    const finalClient = { ...client, id: clientId };
    
    const index = clients.findIndex(c => c.id === clientId);
    if (index > -1) {
      clients[index] = finalClient;
    } else {
      clients.push(finalClient);
    }
    
    localStorage.setItem(`${STORAGE_KEYS.CLIENTS}_${uid}`, JSON.stringify(clients));
    return finalClient;
  },

  // Stats
  calculateStats: (invoices: Invoice[]): DashboardStats => {
    return {
      totalInvoices: invoices.length,
      pendingCount: invoices.filter(i => i.status === 'Pending').length,
      pendingAmount: invoices.filter(i => i.status === 'Pending').reduce((acc, i) => acc + i.totalAmount, 0),
      paidCount: invoices.filter(i => i.status === 'Paid').length,
      paidAmount: invoices.filter(i => i.status === 'Paid').reduce((acc, i) => acc + i.totalAmount, 0),
      overdueCount: invoices.filter(i => i.status === 'Overdue').length,
      overdueAmount: invoices.filter(i => i.status === 'Overdue').reduce((acc, i) => acc + i.totalAmount, 0),
    };
  }
};
