
import React from 'react';
import { Bell, HelpCircle, ChevronDown, Search } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  user: User;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, activeTab, setActiveTab }) => {
  const navItems = ['Dashboard', 'Invoices', 'Clients'];

  return (
    <nav className="h-16 md:h-20 bg-white border-b border-slate-200 fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 md:px-6">
      <div className="flex items-center space-x-8 md:space-x-12">
        <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
          <div className="w-8 h-8 md:w-10 md:h-10 bg-blue-600 rounded-lg md:rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <span className="text-lg md:text-xl font-bold">I+</span>
          </div>
          <span className="text-lg md:text-xl font-bold text-slate-900 tracking-tight whitespace-nowrap">InvoicePlus</span>
        </div>

        <div className="hidden lg:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => setActiveTab(item.toLowerCase())}
              className={`text-sm font-medium transition-colors ${
                activeTab === item.toLowerCase() 
                  ? 'text-blue-600 border-b-2 border-blue-600 py-7' 
                  : 'text-slate-500 hover:text-slate-900 py-7'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center space-x-2 md:space-x-6">
        <div className="hidden lg:flex items-center bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 w-64">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="bg-transparent border-none outline-none text-sm px-2 w-full text-slate-600"
          />
        </div>

        <div className="flex items-center space-x-1 md:space-x-4">
          <button className="p-2 text-slate-500 hover:bg-slate-50 rounded-xl transition-all relative">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
          <button className="hidden sm:block p-2 text-slate-500 hover:bg-slate-50 rounded-xl transition-all">
            <HelpCircle size={20} />
          </button>
        </div>

        <div 
          className="flex items-center space-x-2 md:space-x-3 pl-2 md:pl-6 border-l border-slate-200 group cursor-pointer active:scale-95 transition-transform"
          onClick={() => setActiveTab('settings')}
        >
          <img src={user.avatar} alt={user.name} className="w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl object-cover ring-2 ring-transparent group-hover:ring-blue-100 transition-all shadow-sm" />
          <div className="hidden sm:block text-left">
            <p className="text-xs md:text-sm font-semibold text-slate-900 leading-none truncate max-w-[100px]">{user.name}</p>
            <p className="text-[10px] text-slate-500 mt-1 truncate max-w-[100px] font-medium">{user.companyName}</p>
          </div>
          <ChevronDown size={14} className={`text-slate-400 hidden sm:block transition-transform ${activeTab === 'settings' ? 'rotate-180' : ''}`} />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
