
import React, { useState, useEffect, useRef } from 'react';
import { Plus, Trash2, Save, ArrowLeft, Calendar, FileText, User as UserIcon, Percent, Eye, Send, X, Printer, Download, FileDown, Loader2, Phone, MapPin, Sparkles, QrCode } from 'lucide-react';
import { Invoice, InvoiceItem, Client, User, ItemUnit, InvoiceStatus } from '../types';
import { UNIT_OPTIONS } from '../constants';

// Declare html2pdf for TypeScript
declare var html2pdf: any;

interface InvoiceFormProps {
  initialData?: Invoice | null;
  clients: Client[];
  currentUser: User;
  onSave: (invoice: Invoice) => void;
  onCancel: () => void;
}

const PreviewModal = ({ 
  invoice, 
  user, 
  onClose, 
  onAutoSave,
  autoPrint = false 
}: { 
  invoice: Partial<Invoice>, 
  user: User, 
  onClose: () => void, 
  onAutoSave: (status: InvoiceStatus) => void,
  autoPrint?: boolean 
}) => {
  const [isReady, setIsReady] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    // Fast mount for immediate printing
    const timer = setTimeout(() => {
      setIsReady(true);
    }, 150); // Slightly longer delay to ensure all images/backgrounds are painted
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isReady && autoPrint) {
      handleManualPrint();
    }
  }, [isReady, autoPrint]);

  const subTotal = invoice.items?.reduce((acc, item) => acc + (item.quantity * item.price), 0) || 0;
  const taxTotal = invoice.items?.reduce((acc, item) => acc + ((item.quantity * item.price * (item.tax || 0)) / 100), 0) || 0;
  const totalAmount = subTotal + taxTotal;

  const handleManualPrint = () => {
    onAutoSave('Pending');
    const originalTitle = document.title;
    document.title = `${invoice.invoiceNumber || 'Invoice'}_${(invoice.clientName || '').replace(/\s+/g, '_')}`;
    window.print();
    setTimeout(() => { document.title = originalTitle; }, 1000);
  };

  const handleDownloadPdf = async () => {
    const element = document.getElementById('invoice-capture-area');
    if (!element) return;
    setIsDownloading(true);
    onAutoSave('Pending');
    const opt = {
      margin: 0,
      filename: `${invoice.invoiceNumber || 'INV'}_${(invoice.clientName || 'Invoice').replace(/\s+/g, '_')}.pdf`,
      image: { type: 'jpeg', quality: 1 },
      html2canvas: { scale: 2, useCORS: true, letterRendering: true, height: element.offsetHeight, windowHeight: element.offsetHeight },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['avoid-all'] } 
    };
    try {
      await html2pdf().from(element).set(opt).save();
    } catch (err) {
      console.error("PDF generation failed:", err);
      alert("PDF download failed. Please use the Print button instead.");
    } finally {
      setIsDownloading(false);
    }
  };

  const upiUrl = user.upiId ? `upi://pay?pa=${user.upiId}&pn=${encodeURIComponent(user.companyName)}&am=${totalAmount}&cu=INR&tn=Invoice-${invoice.invoiceNumber}` : null;
  const qrCodeUrl = upiUrl ? `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(upiUrl)}` : null;
  const textColor = user.invoiceTextColor || '#0f172a';

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-0 md:p-4 no-print">
      <div className="bg-white w-full max-w-4xl h-full md:max-h-[95vh] md:rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in duration-200">
        <div className="p-4 md:p-5 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600"><Sparkles size={18} /></div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Document Preview</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">A4 Standard Layout</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button onClick={handleManualPrint} className="px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl flex items-center space-x-2 hover:bg-slate-50 transition-all shadow-sm active:scale-95"><Printer size={18} /><span className="hidden sm:inline">Print Now</span></button>
            <button disabled={isDownloading} onClick={handleDownloadPdf} className="px-5 py-2.5 bg-blue-600 text-white font-bold rounded-xl flex items-center space-x-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 disabled:opacity-50">{isDownloading ? <Loader2 size={18} className="animate-spin" /> : <FileDown size={18} />}<span>{isDownloading ? 'Saving...' : 'Download PDF'}</span></button>
            <button onClick={onClose} className="p-2 text-slate-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all ml-1"><X size={22} /></button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto bg-slate-100 p-4 md:p-10 custom-scrollbar">
          <div id="invoice-capture-area" className="mx-auto bg-white shadow-xl relative overflow-hidden" style={{ width: '210mm', height: '297mm', minHeight: '297mm', padding: '15mm', boxSizing: 'border-box', color: textColor, ...(user.invoiceBackground ? { backgroundImage: `url(${user.invoiceBackground})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}) }}>
            {user.invoiceBackground && <div className="absolute inset-0 bg-white/80 pointer-events-none"></div>}
            <div className="relative z-10 flex flex-col h-full">
              <div className="flex justify-between items-start mb-12">
                <div>
                  {user.companyLogo ? (
                    <img src={user.companyLogo} alt="Logo" className="h-14 w-auto max-w-[180px] object-contain mb-4" />
                  ) : (
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl mb-4">∞</div>
                  )}
                  <h2 className="text-xl font-black leading-tight" style={{ color: textColor }}>{user.companyName}</h2>
                  <div className="mt-1 space-y-0.5 opacity-70">
                    <p className="text-[10px] font-medium">{user.email}</p>
                    {user.companyAddress && <p className="text-[10px] font-medium leading-relaxed max-w-[200px]">{user.companyAddress}</p>}
                  </div>
                </div>
                <div className="text-right">
                  <h1 className="text-4xl font-black mb-1 tracking-tighter" style={{ color: textColor }}>INVOICE</h1>
                  <p className="font-bold uppercase tracking-widest text-[10px] opacity-40">#{invoice.invoiceNumber || 'DRAFT'}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-8 mb-10">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest mb-2 opacity-40">Billed To</p>
                  <h4 className="font-bold text-lg" style={{ color: textColor }}>{invoice.clientName || 'Unnamed Client'}</h4>
                  <div className="mt-1 text-xs space-y-1 opacity-70">
                    {invoice.clientAddress && <p className="whitespace-pre-line leading-relaxed max-w-[250px]">{invoice.clientAddress}</p>}
                    {invoice.clientPhone && <p className="flex items-center"><span className="font-bold opacity-50 mr-2 text-[9px]">MOB</span> {invoice.clientPhone}</p>}
                  </div>
                </div>
                <div className="text-right">
                  <div className="inline-grid grid-cols-2 gap-x-6 gap-y-3">
                    <div>
                      <p className="text-[9px] font-bold uppercase tracking-widest opacity-40">Issue Date</p>
                      <p className="font-bold text-xs">{invoice.issueDate}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold uppercase tracking-widest opacity-40">Due Date</p>
                      <p className="font-bold text-xs">{invoice.dueDate}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex-1">
                <table className="w-full mb-8">
                  <thead>
                    <tr className="border-b-2" style={{ borderBottomColor: textColor }}>
                      <th className="py-3 text-left text-[9px] font-bold uppercase tracking-widest w-12 opacity-40">#</th>
                      <th className="py-3 text-left text-[9px] font-bold uppercase tracking-widest w-1/2 opacity-40">Description</th>
                      <th className="py-3 text-center text-[9px] font-bold uppercase tracking-widest opacity-40">Qty</th>
                      <th className="py-3 text-right text-[9px] font-bold uppercase tracking-widest opacity-40">Price</th>
                      <th className="py-3 text-right text-[9px] font-bold uppercase tracking-widest opacity-40">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100/30">
                    {invoice.items?.map((item, index) => (
                      <tr key={item.id}>
                        <td className="py-4 font-bold text-xs opacity-40">{index + 1}</td>
                        <td className="py-4 font-bold text-sm">{item.name || 'Untitled Item'}</td>
                        <td className="py-4 text-center font-medium text-xs opacity-70">{item.quantity} {item.unit}</td>
                        <td className="py-4 text-right font-medium text-xs opacity-70">{user.currency}{item.price.toLocaleString()}</td>
                        <td className="py-4 text-right font-black text-sm">{user.currency}{(item.quantity * item.price).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-auto">
                <div className="flex justify-between items-end">
                  <div className="flex-1">
                    {qrCodeUrl ? (
                      <div className="flex items-center space-x-4 p-4 border border-black/5 rounded-2xl bg-black/5 w-fit">
                        <img src={qrCodeUrl} alt="UPI QR" className="w-20 h-20 mix-blend-multiply" />
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-widest mb-1 opacity-40">Scan to Pay</p>
                          <p className="text-xs font-bold">{user.upiId}</p>
                          <p className="text-[9px] font-medium mt-1 opacity-50">Accepting all UPI apps</p>
                        </div>
                      </div>
                    ) : <div className="h-20"></div>}
                  </div>
                  <div className="w-full max-w-[240px] space-y-3">
                    <div className="flex justify-between text-xs opacity-70"><span className="font-medium">Subtotal</span><span className="font-bold">{user.currency}{subTotal.toLocaleString()}</span></div>
                    <div className="flex justify-between text-xs"><span className="font-medium opacity-70">Tax Amount</span><span className="font-bold text-orange-600">{user.currency}{taxTotal.toLocaleString()}</span></div>
                    <div className="pt-4 border-t-2 flex justify-between items-center" style={{ borderTopColor: textColor }}><span className="font-black text-sm uppercase tracking-tighter">Total</span><span className="font-black text-blue-600 text-2xl tracking-tighter">{user.currency}{totalAmount.toLocaleString()}</span></div>
                  </div>
                </div>
                {invoice.notes && (
                  <div className="mt-10 pt-6 border-t border-black/5">
                    <p className="text-[9px] font-bold uppercase tracking-widest mb-2 opacity-40">Notes & Terms</p>
                    <p className="text-[10px] leading-relaxed max-w-2xl italic font-medium opacity-70">{invoice.notes}</p>
                  </div>
                )}
                <div className="mt-12 text-center pb-4">
                  <p className="text-[9px] font-bold uppercase tracking-[0.2em] mb-1 opacity-30">Thank you for your business</p>
                  <p className="text-[8px] font-bold uppercase opacity-40">Generated by Infinity &bull; {user.companyName}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InvoiceForm: React.FC<InvoiceFormProps> = ({ initialData, clients, currentUser, onSave, onCancel }) => {
  const [invoice, setInvoice] = useState<Partial<Invoice>>({
    invoiceNumber: initialData?.invoiceNumber || 'INV-' + Date.now().toString().slice(-6),
    clientId: initialData?.clientId || '',
    clientName: initialData?.clientName || '',
    clientAddress: initialData?.clientAddress || '',
    clientPhone: initialData?.clientPhone || '',
    issueDate: initialData?.issueDate || new Date().toISOString().split('T')[0],
    dueDate: initialData?.dueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    items: initialData?.items || [{ id: Math.random().toString(36).substr(2, 9), itemNumber: 1, name: '', quantity: 1, unit: 'unit', price: 0, tax: currentUser.taxRate }],
    status: initialData?.status || 'Draft',
    notes: initialData?.notes || '',
  });

  const [globalTax, setGlobalTax] = useState<number>(currentUser.taxRate);
  const [showPreview, setShowPreview] = useState(false);
  const [autoPrint, setAutoPrint] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Synchronize item numbers whenever items array changes
  useEffect(() => {
    if (invoice.items) {
      const needsUpdate = invoice.items.some((item, index) => item.itemNumber !== index + 1);
      if (needsUpdate) {
        const renumberedItems = invoice.items.map((item, index) => ({
          ...item,
          itemNumber: index + 1
        }));
        setInvoice(prev => ({ ...prev, items: renumberedItems }));
      }
    }
  }, [invoice.items?.length]);

  const handleAddItem = () => {
    const nextNum = (invoice.items?.length || 0) + 1;
    const newItem: InvoiceItem = {
      id: Math.random().toString(36).substr(2, 9),
      itemNumber: nextNum,
      name: '',
      quantity: 1,
      unit: 'unit',
      price: 0,
      tax: globalTax,
    };
    setInvoice({ ...invoice, items: [...(invoice.items || []), newItem] });
  };

  const handleRemoveItem = (id: string) => {
    if ((invoice.items?.length || 0) <= 1) return;
    setInvoice({ ...invoice, items: invoice.items?.filter(item => item.id !== id) });
  };

  const handleItemChange = (id: string, field: keyof InvoiceItem, value: any) => {
    const newItems = invoice.items?.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    setInvoice({ ...invoice, items: newItems });
  };

  const handleGlobalTaxChange = (val: number) => {
    setGlobalTax(val);
    const newItems = invoice.items?.map(item => ({ ...item, tax: val }));
    setInvoice({ ...invoice, items: newItems });
  };

  const handleClientChange = (clientId: string) => {
    if (clientId === 'manual') {
      setInvoice({ ...invoice, clientId: '', clientName: '', clientAddress: '', clientPhone: '' });
      return;
    }
    const client = clients.find(c => c.id === clientId);
    setInvoice({ 
      ...invoice, 
      clientId, 
      clientName: client?.name || '', 
      clientAddress: client?.address || '', 
      clientPhone: client?.phone || '' 
    });
  };

  const calculateTotals = () => {
    const items = invoice.items || [];
    const subTotal = items.reduce((acc, item) => acc + (item.quantity * item.price), 0);
    const taxTotal = items.reduce((acc, item) => acc + ((item.quantity * item.price * (item.tax || 0)) / 100), 0);
    const totalAmount = subTotal + taxTotal;
    return { subTotal, taxTotal, totalAmount };
  };

  const { subTotal, taxTotal, totalAmount } = calculateTotals();

  const handleAction = async (status: InvoiceStatus) => {
    if (!invoice.clientName) {
      alert("Please enter a client name.");
      return;
    }
    setIsSaving(true);
    await new Promise(r => setTimeout(r, 600));
    onSave({
      ...invoice,
      ...calculateTotals(),
      status,
      id: initialData?.id || Math.random().toString(36).substr(2, 9)
    } as Invoice);
    setIsSaving(false);
  };

  const handleTriggerPrint = (e: React.MouseEvent) => {
    e.preventDefault();
    setAutoPrint(true);
    setShowPreview(true);
  };

  return (
    <div className="max-w-6xl mx-auto pb-20 animate-in slide-in-from-bottom-4 duration-500">
      {showPreview && (
        <PreviewModal 
          invoice={invoice} 
          user={currentUser} 
          autoPrint={autoPrint} 
          onAutoSave={(status) => { 
            onSave({ ...invoice, ...calculateTotals(), status, id: initialData?.id || Math.random().toString(36).substr(2, 9) } as Invoice); 
          }} 
          onClose={() => { 
            setShowPreview(false); 
            setAutoPrint(false); 
          }} 
        />
      )}
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 space-y-4 md:space-y-0 print:hidden">
        <button type="button" onClick={onCancel} className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 font-medium transition-all group">
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          <span>Back</span>
        </button>
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button type="button" onClick={() => { setAutoPrint(false); setShowPreview(true); }} className="flex-1 md:flex-none px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-all flex items-center justify-center space-x-2 shadow-sm"><Eye size={18} /><span className="hidden md:inline">Preview</span></button>
          <button type="button" onClick={handleTriggerPrint} className="flex-1 md:flex-none px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-all flex items-center justify-center space-x-2 shadow-sm active:scale-95"><Printer size={18} /><span className="hidden md:inline">Print Menu</span></button>
          <button type="button" onClick={() => { setAutoPrint(false); setShowPreview(true); }} className="flex-1 md:flex-none px-4 py-2.5 bg-blue-50 border border-blue-100 text-blue-600 font-bold rounded-xl hover:bg-blue-100 transition-all flex items-center justify-center space-x-2 shadow-sm active:scale-95"><FileDown size={18} /><span>Save PDF</span></button>
          <button type="button" disabled={isSaving} onClick={() => handleAction('Draft')} className="flex-1 md:flex-none px-4 py-2.5 bg-white border border-slate-200 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition-all shadow-sm flex items-center justify-center space-x-2 disabled:opacity-50">{isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}<span>Draft</span></button>
          <button type="button" disabled={isSaving} onClick={() => handleAction(invoice.status === 'Paid' ? 'Paid' : 'Pending')} className="flex-[2] md:flex-none px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all flex items-center justify-center space-x-2 shadow-lg shadow-blue-200 disabled:opacity-50">{isSaving ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}<span>Publish Invoice</span></button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 print:hidden">
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8">
            <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center space-x-2"><FileText size={20} className="text-blue-600" /><span>Invoice & Client Details</span></h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Invoice Number</label><input type="text" value={invoice.invoiceNumber} onChange={(e) => setInvoice({...invoice, invoiceNumber: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-bold text-blue-600" /></div>
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select Saved Client</label><div className="relative"><select value={invoice.clientId || (invoice.clientName ? 'manual' : '')} onChange={(e) => handleClientChange(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium appearance-none"><option value="">-- Choose Client --</option><option value="manual">Manual Entry / New Client</option>{clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select><UserIcon size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" /></div></div>
            </div>
            <div className="pt-6 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Client Name</label><div className="relative"><input type="text" placeholder="Enter Client Name" value={invoice.clientName} onChange={(e) => setInvoice({...invoice, clientName: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium" /><UserIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /></div></div>
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Mobile Number</label><div className="relative"><input type="tel" placeholder="e.g. +91 98765 43210" value={invoice.clientPhone} onChange={(e) => setInvoice({...invoice, clientPhone: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium" /><Phone size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /></div></div>
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">CLIENT ADDRESS</label><div className="relative"><input type="text" placeholder="Street, City, State" value={invoice.clientAddress} onChange={(e) => setInvoice({...invoice, clientAddress: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium" /><MapPin size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /></div></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Issue Date</label><input type="date" value={invoice.issueDate} onChange={(e) => setInvoice({...invoice, issueDate: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium" /></div>
              <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Due Date</label><input type="date" value={invoice.dueDate} onChange={(e) => setInvoice({...invoice, dueDate: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium" /></div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-900">Line Items</h3>
              <button type="button" onClick={handleAddItem} className="text-blue-600 hover:text-blue-700 text-sm font-bold flex items-center space-x-1"><Plus size={16} /><span>Add Item</span></button>
            </div>
            <div className="space-y-4">
              {invoice.items?.map((item, index) => (
                <div key={item.id} className="grid grid-cols-12 gap-3 items-end p-4 bg-slate-50 rounded-2xl relative">
                  <div className="col-span-12 md:col-span-0.5 mb-2 md:mb-0">
                    <span className="w-6 h-6 bg-slate-200 text-slate-500 rounded-full flex items-center justify-center text-[10px] font-black">{index + 1}</span>
                  </div>
                  <div className="col-span-12 md:col-span-3.5 space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Description</label>
                    <input type="text" placeholder="Service or Product name" value={item.name} onChange={(e) => handleItemChange(item.id, 'name', e.target.value)} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium outline-none" />
                  </div>
                  <div className="col-span-4 md:col-span-1.5 space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Qty</label>
                    <input type="number" min="1" value={item.quantity} onChange={(e) => handleItemChange(item.id, 'quantity', parseFloat(e.target.value) || 0)} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium outline-none" />
                  </div>
                  <div className="col-span-4 md:col-span-2 space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Price</label>
                    <input type="number" value={item.price} onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value) || 0)} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium outline-none" />
                  </div>
                  <div className="col-span-4 md:col-span-2 space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Unit</label>
                    <select value={item.unit} onChange={(e) => handleItemChange(item.id, 'unit', e.target.value as ItemUnit)} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium outline-none">{UNIT_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}</select>
                  </div>
                  <div className="col-span-10 md:col-span-2 space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right block">Total</label>
                    <div className="w-full bg-slate-100/50 border border-slate-200 rounded-lg px-2 py-2 text-[11px] font-bold text-slate-900 text-right">{currentUser.currency}{(item.quantity * item.price).toLocaleString()}</div>
                  </div>
                  <div className="col-span-2 md:col-span-0.5 flex justify-center pb-2">
                    <button type="button" onClick={() => handleRemoveItem(item.id)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 sticky top-24">
            <h3 className="text-lg font-bold text-slate-900 mb-6 border-b border-slate-50 pb-4">Order Summary</h3>
            <div className="space-y-6">
              <div className="flex justify-between items-center text-slate-500"><span className="text-sm font-medium">Subtotal</span><span className="text-sm font-bold text-slate-900">{currentUser.currency}{subTotal.toLocaleString()}</span></div>
              <div className="pt-4 border-t border-slate-50 space-y-2">
                <div className="flex justify-between items-center"><label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tax Rate (%)</label><div className="relative w-24"><input type="number" value={globalTax} onChange={(e) => handleGlobalTaxChange(parseFloat(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-3 pr-7 py-2 text-sm font-bold text-orange-600 outline-none focus:ring-2 focus:ring-orange-100" /><Percent size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" /></div></div>
                <div className="flex justify-between items-center text-slate-500"><span className="text-xs font-medium italic">Tax Amount</span><span className="text-sm font-bold text-orange-600">{currentUser.currency}{taxTotal.toLocaleString()}</span></div>
              </div>
              <div className="pt-6 border-t border-slate-100 flex justify-between items-center"><span className="text-base font-bold text-slate-900">Total</span><span className="text-xl font-black text-blue-600">{currentUser.currency}{totalAmount.toLocaleString()}</span></div>
            </div>
            <div className="grid grid-cols-1 gap-3 mt-8">
              <button type="button" onClick={handleTriggerPrint} className="w-full bg-blue-50 text-blue-600 border border-blue-100 font-bold py-3.5 rounded-xl flex items-center justify-center space-x-2 transition-all hover:bg-blue-100 active:scale-95"><Printer size={18} /><span>Print Document</span></button>
              <button type="button" disabled={isSaving} onClick={() => handleAction(invoice.status === 'Paid' ? 'Paid' : 'Pending')} className="w-full bg-blue-600 text-white font-bold py-3.5 rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-blue-100 transition-all hover:bg-blue-700 active:scale-95 disabled:opacity-50">{isSaving ? <Loader2 size={20} className="animate-spin" /> : <Save size={18} />}<span>{invoice.status === 'Draft' ? 'Publish Invoice' : 'Update Invoice'}</span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceForm;
