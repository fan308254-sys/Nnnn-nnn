
import React, { useState, useRef } from 'react';
import { User as UserIcon, Building, Mail, Camera, Save, CheckCircle, Globe, CreditCard, Image as ImageIcon, Trash2, ShieldCheck, QrCode, Loader2, Palette, MapPin } from 'lucide-react';
import { User } from '../types';

interface SettingsProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

const Settings: React.FC<SettingsProps> = ({ user, onUpdateUser }) => {
  const [formData, setFormData] = useState<User>({ 
    ...user, 
    invoiceTextColor: user.invoiceTextColor || '#0f172a' 
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'avatar' | 'invoiceBackground' | 'companyLogo') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, [field]: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    setTimeout(() => {
      onUpdateUser(formData);
      setIsSaving(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Account Settings</h1>
          <p className="text-slate-500 mt-1">Manage your profile and company branding.</p>
        </div>
        {showSuccess && (
          <div className="flex items-center space-x-2 text-green-600 bg-green-50 px-4 py-2 rounded-xl font-bold animate-in fade-in zoom-in">
            <CheckCircle size={18} />
            <span>Changes saved!</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Sidebar */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm text-center">
            <div className="relative inline-block group">
              <img 
                src={formData.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.name)}&background=2563EB&color=fff`} 
                alt="Profile" 
                className="w-32 h-32 rounded-3xl object-cover ring-4 ring-slate-50 shadow-lg"
              />
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2.5 rounded-xl shadow-lg hover:bg-blue-700 transition-all active:scale-90"
                title="Change Profile Image"
              >
                <Camera size={18} />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={(e) => handleImageUpload(e, 'avatar')}
              />
            </div>
            <h3 className="mt-6 text-xl font-bold text-slate-900">{formData.name}</h3>
            <p className="text-slate-500 text-sm font-medium">{formData.companyName}</p>
          </div>
          
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Invoice Branding</h4>
            <div className="space-y-6">
              {/* Company Logo Section */}
              <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Company Logo</label>
                 <div className="relative w-full aspect-video bg-slate-50 rounded-2xl overflow-hidden border-2 border-dashed border-slate-200 flex items-center justify-center group">
                    {formData.companyLogo ? (
                      <div className="relative w-full h-full p-2">
                        <img src={formData.companyLogo} className="w-full h-full object-contain" alt="Logo Preview" />
                        <button 
                          onClick={() => setFormData({...formData, companyLogo: undefined})}
                          className="absolute top-2 right-2 bg-red-500 text-white p-1.5 rounded-lg shadow-lg hover:bg-red-600 transition-all"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ) : (
                      <div className="text-center cursor-pointer" onClick={() => logoInputRef.current?.click()}>
                        <ShieldCheck size={28} className="text-slate-300 mx-auto mb-1" />
                        <p className="text-[10px] text-slate-400 font-bold uppercase">No Logo</p>
                      </div>
                    )}
                 </div>
                 <button 
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="w-full py-2 bg-blue-50 text-blue-600 text-xs font-bold rounded-xl hover:bg-blue-100 transition-all flex items-center justify-center space-x-2"
                >
                  <Camera size={14} />
                  <span>{formData.companyLogo ? 'Change Logo' : 'Upload Logo'}</span>
                </button>
                <input 
                  type="file" 
                  ref={logoInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleImageUpload(e, 'companyLogo')}
                />
              </div>

              {/* Text Color Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Invoice Text Color</label>
                <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="relative w-10 h-10 rounded-lg overflow-hidden border border-slate-200 shadow-sm shrink-0">
                    <input 
                      type="color" 
                      value={formData.invoiceTextColor}
                      onChange={(e) => setFormData({...formData, invoiceTextColor: e.target.value})}
                      className="absolute inset-0 w-[150%] h-[150%] -top-[25%] -left-[25%] cursor-pointer"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-700 uppercase">{formData.invoiceTextColor}</p>
                    <p className="text-[9px] text-slate-400 font-medium leading-none">Primary text color</p>
                  </div>
                  <Palette size={16} className="text-slate-300" />
                </div>
              </div>

              {/* Background Image Section */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Invoice Background</label>
                <div className="relative aspect-[4/3] bg-slate-50 rounded-2xl overflow-hidden border-2 border-dashed border-slate-200 flex flex-col items-center justify-center p-2">
                  {formData.invoiceBackground ? (
                    <>
                      <img src={formData.invoiceBackground} className="absolute inset-0 w-full h-full object-cover opacity-50" alt="Background Preview" />
                      <div className="relative z-10 w-full h-full flex flex-col items-center justify-center">
                        <button 
                          onClick={() => setFormData({...formData, invoiceBackground: undefined})}
                          className="bg-red-500 text-white p-2 rounded-lg shadow-lg hover:bg-red-600 transition-all mb-2"
                        >
                          <Trash2 size={16} />
                        </button>
                        <span className="text-[10px] font-black uppercase text-slate-900 bg-white/80 px-2 py-1 rounded">Background Active</span>
                      </div>
                    </>
                  ) : (
                    <div className="text-center cursor-pointer" onClick={() => bgInputRef.current?.click()}>
                      <ImageIcon size={32} className="text-slate-300 mx-auto mb-2" />
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">No Background</p>
                    </div>
                  )}
                </div>
                <button 
                  type="button"
                  onClick={() => bgInputRef.current?.click()}
                  className="w-full py-2 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-all flex items-center justify-center space-x-2"
                >
                  <ImageIcon size={14} />
                  <span>{formData.invoiceBackground ? 'Change BG' : 'Upload BG'}</span>
                </button>
                <input 
                  type="file" 
                  ref={bgInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleImageUpload(e, 'invoiceBackground')}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        <div className="md:col-span-2 space-y-6">
          <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-8 border-b border-slate-50">
              <h3 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                <UserIcon size={20} className="text-blue-600" />
                <span>Personal Information</span>
              </h3>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                  <input 
                    type="text" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white transition-all font-medium"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                  <input 
                    type="email" 
                    value={formData.email}
                    disabled
                    className="w-full bg-slate-100 border border-slate-200 rounded-2xl px-4 py-3 outline-none text-slate-400 font-medium cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="space-y-2 pt-6 border-t border-slate-50">
                <h3 className="text-lg font-bold text-slate-900 flex items-center space-x-2 mb-4">
                  <Building size={20} className="text-blue-600" />
                  <span>Company Details</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2 col-span-1 sm:col-span-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Company Name</label>
                    <input 
                      type="text" 
                      value={formData.companyName}
                      onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white transition-all font-medium"
                      required
                    />
                  </div>
                  <div className="space-y-2 col-span-1 sm:col-span-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Company Address</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-4 text-slate-400 group-focus-within:text-blue-600 transition-colors">
                        <MapPin size={18} />
                      </div>
                      <textarea 
                        placeholder="Enter full business address"
                        value={formData.companyAddress || ''}
                        onChange={(e) => setFormData({...formData, companyAddress: e.target.value})}
                        rows={3}
                        className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white transition-all font-medium resize-none"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Default Currency</label>
                    <select 
                      value={formData.currency}
                      onChange={(e) => setFormData({...formData, currency: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white transition-all font-medium"
                    >
                      <option value="₹">₹ (INR)</option>
                      <option value="$">$ (USD)</option>
                      <option value="€">€ (EUR)</option>
                      <option value="£">£ (GBP)</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-2 pt-6 border-t border-slate-50">
                <h3 className="text-lg font-bold text-slate-900 flex items-center space-x-2 mb-4">
                  <CreditCard size={20} className="text-blue-600" />
                  <span>Payment Information</span>
                </h3>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">UPI ID (e.g. name@bank)</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600">
                      <QrCode size={18} />
                    </div>
                    <input 
                      type="text" 
                      placeholder="alex@okaxis"
                      value={formData.upiId || ''}
                      onChange={(e) => setFormData({...formData, upiId: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white transition-all font-medium"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium ml-1">This will generate a payment QR code directly on your invoices.</p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-50 flex justify-end">
              <button 
                type="submit"
                disabled={isSaving}
                className="px-8 py-3 bg-blue-600 text-white font-bold rounded-2xl flex items-center space-x-2 shadow-lg shadow-blue-200 transition-all hover:bg-blue-700 active:scale-95 disabled:opacity-50"
              >
                {isSaving ? (
                   <span className="flex items-center space-x-2">
                    <Loader2 size={20} className="animate-spin" />
                    <span>Saving...</span>
                   </span>
                ) : (
                  <>
                    <Save size={18} />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Settings;
