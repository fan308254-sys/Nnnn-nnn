
import React, { useState } from 'react';
import { Mail, Lock, AlertCircle, Loader2, KeyRound, Send, Inbox, UserPlus, LogIn, Sparkles, CheckCircle2 } from 'lucide-react';
import { db } from '../services/db';
import { User } from '../types';

interface LoginFormProps {
  onLogin: (user: User) => void;
}

type AuthMode = 'login' | 'register' | 'forgot' | 'check_email';

const PLANS = [
  { name: 'Infinity Basic', price: '0', description: 'Free forever for individuals' },
  { name: 'Infinity Pro', price: '999', description: 'Advanced reporting & branding' },
  { name: 'Infinity Enterprise', price: '4999', description: 'Unlimited users & priority support' }
];

// Google Brand Icon SVG
const GoogleIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [selectedPlanIndex, setSelectedPlanIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbw0tAHXv9Ix3J8z1lJ9TkRp54OC5TIrKnUgFaM1I2k-4_WOHTlEPxvIiF99_9_3rxJD/exec';

  const sendToGoogleScript = async (data: any) => {
    try {
      // Use no-cors if the script doesn't handle OPTIONS preflight, 
      // but standard POST is usually better for data integrity if it works.
      await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', // Common for simple Google Script Web Apps
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.error('Failed to sync with Google Script:', err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const payload = {
      name: name || email.split('@')[0],
      email: email,
      password: password,
      selectedProduct: PLANS[selectedPlanIndex].name,
      totalAmount: PLANS[selectedPlanIndex].price,
      timestamp: new Date().toISOString(),
      action: mode
    };

    // First, send to Google Script as requested
    await sendToGoogleScript(payload);

    // Continue with local application logic
    await new Promise(r => setTimeout(r, 800));

    try {
      if (mode === 'login') {
        const user = await db.validateUser(email, password);
        if (user) {
          onLogin(user);
        } else {
          setError('User not found. Try registering instead.');
        }
      } 
      else if (mode === 'register') {
        const uid = Math.random().toString(36).substr(2, 9);
        const newUser: User = {
          id: uid,
          name: name || email.split('@')[0],
          email: email,
          companyName: `${name || 'My'} Ventures`,
          taxRate: 18,
          currency: '₹',
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name || email)}&background=2563EB&color=fff`,
        };
        
        await db.registerUser(newUser);
        onLogin(newUser);
      } 
      else if (mode === 'forgot') {
        setMode('check_email');
      }
    } catch (err: any) {
      setError('System error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    setError(null);
    
    // Simulate Google OAuth Popup
    await new Promise(r => setTimeout(r, 1500));
    
    try {
      const mockGoogleUid = 'google_' + Math.random().toString(36).substr(2, 9);
      const googleUser: User = {
        id: mockGoogleUid,
        name: 'Google User',
        email: 'user@google.com',
        companyName: 'Google Workspace User',
        taxRate: 18,
        currency: '₹',
        avatar: 'https://lh3.googleusercontent.com/a/default-user',
      };
      
      // Sync Google Login data to script too
      await sendToGoogleScript({
        name: googleUser.name,
        email: googleUser.email,
        password: 'OAUTH_PROVIDER',
        selectedProduct: 'Infinity Basic',
        totalAmount: '0',
        timestamp: new Date().toISOString(),
        action: 'google_login'
      });

      // Check if user already exists locally by email
      const existingUsersJson = localStorage.getItem('invoiceplus_registered_users');
      const existingUsers = existingUsersJson ? JSON.parse(existingUsersJson) : {};
      const found = Object.values(existingUsers).find((u: any) => u.email === googleUser.email) as User | undefined;
      
      if (found) {
        onLogin(found);
      } else {
        await db.registerUser(googleUser);
        onLogin(googleUser);
      }
    } catch (err) {
      setError('Google Sign-In failed. Please try again.');
    } finally {
      setGoogleLoading(false);
    }
  };

  const renderFormContent = () => {
    switch (mode) {
      case 'login':
        return (
          <>
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold text-slate-900">Welcome Back</h1>
              <p className="text-slate-500 mt-1 font-medium">Local Billing Access</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Email</label>
                <div className="relative group">
                  <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input type="email" placeholder="alex@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl pl-12 pr-4 py-3.5 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between items-center ml-1">
                  <label className="text-xs font-bold text-slate-400 uppercase">Password</label>
                  <button type="button" onClick={() => setMode('forgot')} className="text-xs font-bold text-blue-600 hover:underline">Forgot?</button>
                </div>
                <div className="relative group">
                  <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input type="password" placeholder="Any password works for local demo" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl pl-12 pr-4 py-3.5 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
                </div>
              </div>
              <button type="submit" disabled={loading || googleLoading} className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-4 rounded-2xl shadow-lg transition-all active:scale-95 mt-4 flex items-center justify-center space-x-2">
                {loading ? <Loader2 size={20} className="animate-spin" /> : <><LogIn size={20} /><span>Sign In</span></>}
              </button>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-200"></span></div>
                <div className="relative flex justify-center text-xs uppercase"><span className="bg-white/80 backdrop-blur px-2 text-slate-400 font-bold tracking-widest">Or continue with</span></div>
              </div>

              <button 
                type="button" 
                onClick={handleGoogleLogin}
                disabled={loading || googleLoading}
                className="w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold py-3.5 rounded-2xl shadow-sm transition-all active:scale-95 flex items-center justify-center space-x-3 disabled:opacity-50"
              >
                {googleLoading ? <Loader2 size={20} className="animate-spin text-blue-500" /> : <GoogleIcon />}
                <span>{googleLoading ? 'Connecting...' : 'Sign in with Google'}</span>
              </button>
            </form>
            <div className="mt-8 text-center">
              <p className="text-slate-500 text-sm">New to Infinity? <button onClick={() => setMode('register')} className="text-blue-600 font-bold hover:underline">Create Account</button></p>
            </div>
          </>
        );
      case 'register':
        return (
          <>
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Get Started</h1>
              <p className="text-slate-500 mt-1 font-medium">Setup your local profile</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Your Name</label>
                <input type="text" placeholder="John Doe" value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Email</label>
                <input type="email" placeholder="john@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Password</label>
                <input type="password" placeholder="Create a password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
              </div>
              
              <div className="space-y-2 mt-4">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Select Plan (Product)</label>
                <div className="grid grid-cols-1 gap-2">
                  {PLANS.map((plan, idx) => (
                    <button
                      key={plan.name}
                      type="button"
                      onClick={() => setSelectedPlanIndex(idx)}
                      className={`text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                        selectedPlanIndex === idx 
                          ? 'bg-blue-50 border-blue-200 ring-1 ring-blue-100' 
                          : 'bg-white border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div>
                        <p className={`text-xs font-bold ${selectedPlanIndex === idx ? 'text-blue-700' : 'text-slate-700'}`}>{plan.name}</p>
                        <p className="text-[10px] text-slate-500">{plan.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-black text-slate-900">₹{plan.price}</p>
                        {selectedPlanIndex === idx && <CheckCircle2 size={14} className="text-blue-600 inline ml-1" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-4 rounded-2xl shadow-lg transition-all active:scale-95 mt-4 flex items-center justify-center space-x-2">
                {loading ? <Loader2 size={20} className="animate-spin" /> : <><UserPlus size={20} /><span>Register & Start</span></>}
              </button>
            </form>
            <div className="mt-4 text-center">
              <button onClick={() => setMode('login')} className="text-blue-600 font-bold hover:underline text-sm">Already registered? Login</button>
            </div>
          </>
        );
      case 'forgot':
        return (
          <>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-50/80 backdrop-blur rounded-2xl flex items-center justify-center text-blue-600 mx-auto mb-6">
                <KeyRound size={32} />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">Reset Password</h1>
              <p className="text-slate-500 mt-2 text-sm px-4 leading-relaxed font-medium">
                Enter your email to receive a recovery link.
              </p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                <div className="relative group">
                  <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input type="email" placeholder="your@email.com" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-white/50 border border-slate-100/50 rounded-2xl pl-12 pr-4 py-4 outline-none focus:ring-2 focus:ring-blue-100/50 font-medium backdrop-blur-sm" required />
                </div>
              </div>
              <button type="submit" disabled={loading} className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg hover:bg-blue-700 transition-all active:scale-95 flex items-center justify-center space-x-2">
                {loading ? <Loader2 size={20} className="animate-spin" /> : <><Send size={18} /><span>Send Link</span></>}
              </button>
              <button type="button" onClick={() => setMode('login')} className="w-full text-xs font-bold text-slate-400 hover:text-slate-600">Cancel</button>
            </form>
          </>
        );
      case 'check_email':
        return (
          <>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-50/80 backdrop-blur rounded-2xl flex items-center justify-center text-blue-600 mx-auto mb-6">
                <Inbox size={32} />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">Link Dispatched</h1>
              <p className="text-slate-500 mt-2 text-sm px-4 leading-relaxed font-medium">
                (Simulated) Link sent to <span className="font-bold text-slate-900">{email}</span>.
              </p>
            </div>
            <div className="space-y-4">
              <button onClick={() => setMode('login')} className="w-full bg-slate-900 text-white font-bold py-4 rounded-2xl flex items-center justify-center space-x-2 shadow-lg transition-all active:scale-95">
                <span>Return to Login</span>
              </button>
            </div>
          </>
        );
      default: return null;
    }
  };

  return (
    <div 
      className="min-h-screen bg-cover bg-center flex items-center justify-center p-4 relative overflow-hidden"
      style={{ backgroundImage: 'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTK-mFqPsFDAnoVsUKjkQfXgNfr5cdp6RL6DVpr-99KXw&s=10")' }}
    >
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[4px]"></div>

      <div className="max-w-md w-full bg-white/80 backdrop-blur-xl rounded-[3rem] shadow-2xl border border-white/30 overflow-hidden animate-in fade-in zoom-in duration-500 relative z-10 flex flex-col">
        <div className="p-8 pb-0 flex justify-center mt-6">
           <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-200"><span className="text-3xl font-bold">∞</span></div>
        </div>
        <div className="p-8 pt-6 min-h-[480px] flex flex-col justify-center">
          {error && (
            <div className="mb-6 p-4 bg-red-50/90 border border-red-100 rounded-2xl flex items-start space-x-3 text-red-600 animate-in slide-in-from-top-2 backdrop-blur-sm">
              <AlertCircle size={20} className="shrink-0" />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}
          {renderFormContent()}
        </div>
        <div className="bg-white/40 p-4 text-center border-t border-white/20 backdrop-blur-md">
           <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] flex items-center justify-center">
             <Sparkles size={12} className="mr-1.5 text-blue-500" />
             CREATE BY RITESH BILLORE
           </p>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
