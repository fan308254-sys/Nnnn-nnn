
import React, { useMemo, useState } from 'react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Cell, AreaChart, Area, PieChart, Pie, Line
} from 'recharts';
import { 
  FileText, Clock, CheckCircle, AlertCircle, TrendingUp, Plus, Send, Eye, FileDown, ChevronDown, Sparkles, Loader2, BarChart3
} from 'lucide-react';
import { Invoice, DashboardStats, User } from '../types';

// Declare html2pdf for TypeScript
declare var html2pdf: any;

interface DashboardProps {
  stats: DashboardStats;
  invoices: Invoice[];
  user: User;
  onViewAllInvoices: () => void;
  onCreateInvoice: () => void;
  onViewInvoice: (id: string) => void;
  onStatusChange: (e: React.ChangeEvent<HTMLSelectElement>, id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  stats, invoices, user, onViewAllInvoices, onCreateInvoice, onViewInvoice, onStatusChange 
}) => {
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  
  // Calculate real monthly data from invoices
  const monthlyRevenueData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const now = new Date();
    const result = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthLabel = months[d.getMonth()];
      const year = d.getFullYear();
      const monthIndex = d.getMonth();

      const monthlyInvoices = invoices.filter(inv => {
        const invDate = new Date(inv.issueDate);
        return invDate.getMonth() === monthIndex && invDate.getFullYear() === year;
      });

      const totalAmount = monthlyInvoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
      const paidAmount = monthlyInvoices
        .filter(inv => inv.status === 'Paid')
        .reduce((acc, inv) => acc + inv.totalAmount, 0);

      result.push({
        month: monthLabel,
        amount: totalAmount,
        paid: paidAmount
      });
    }
    return result;
  }, [invoices]);

  const currentMonthTotal = useMemo(() => {
    const now = new Date();
    return invoices
      .filter(inv => {
        const invDate = new Date(inv.issueDate);
        return invDate.getMonth() === now.getMonth() && invDate.getFullYear() === now.getFullYear();
      })
      .reduce((acc, inv) => acc + inv.totalAmount, 0);
  }, [invoices]);

  const clientData = [
    { name: 'Paid', value: stats.paidCount, color: '#10B981' },
    { name: 'Pending', value: stats.pendingCount, color: '#F59E0B' },
    { name: 'Overdue', value: stats.overdueCount, color: '#EF4444' },
  ];

  const formatCurrency = (val: number) => {
    return `${user.currency}${val.toLocaleString()}`;
  };

  const handleDownloadReport = async () => {
    if (invoices.length === 0) {
      alert("No invoices found to generate a report.");
      return;
    }

    setIsGeneratingReport(true);
    const element = document.getElementById('business-report-template');
    if (!element) return;

    // Show temporary for capture
    element.style.display = 'block';

    const opt = {
      margin: 0,
      filename: `Business_Report_${user.companyName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, letterRendering: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    try {
      await html2pdf().from(element).set(opt).save();
    } catch (err) {
      console.error("Report generation failed:", err);
    } finally {
      element.style.display = 'none';
      setIsGeneratingReport(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Hidden Design Template for PDF Report */}
      <div id="business-report-template" style={{ display: 'none', width: '210mm', minHeight: '297mm', padding: '20mm', background: 'white', color: '#0f172a' }}>
        <div className="flex justify-between items-start border-b-2 border-slate-100 pb-10 mb-10">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">I+</div>
              <h1 className="text-2xl font-black tracking-tighter">BUSINESS REPORT</h1>
            </div>
            <h2 className="text-lg font-bold text-slate-900">{user.companyName}</h2>
            <p className="text-sm text-slate-500">{user.email}</p>
            <p className="text-xs text-slate-400 mt-1">{user.companyAddress}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Generated On</p>
            <p className="text-sm font-bold">{new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
            <div className="mt-4 bg-blue-50 px-4 py-2 rounded-xl inline-block border border-blue-100">
               <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wider mb-0.5 text-center">Net Revenue</p>
               <p className="text-xl font-black text-blue-700">{formatCurrency(stats.paidAmount + stats.pendingAmount)}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6 mb-12">
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Collected</p>
            <p className="text-2xl font-black text-green-600">{formatCurrency(stats.paidAmount)}</p>
            <p className="text-[10px] font-medium text-slate-500 mt-1">{stats.paidCount} Paid Invoices</p>
          </div>
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Pending</p>
            <p className="text-2xl font-black text-orange-500">{formatCurrency(stats.pendingAmount)}</p>
            <p className="text-[10px] font-medium text-slate-500 mt-1">{stats.pendingCount} Pending Invoices</p>
          </div>
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Overdue</p>
            <p className="text-2xl font-black text-red-500">{formatCurrency(stats.overdueAmount)}</p>
            <p className="text-[10px] font-medium text-slate-500 mt-1">{stats.overdueCount} Overdue Invoices</p>
          </div>
        </div>

        <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-4 flex items-center">
          <FileText size={14} className="mr-2 text-blue-600" />
          Recent Transaction Log
        </h3>
        <table className="w-full text-left text-sm mb-12 border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-900/5">
              <th className="py-3 px-2 text-[10px] font-bold text-slate-400 uppercase">Inv #</th>
              <th className="py-3 px-2 text-[10px] font-bold text-slate-400 uppercase">Client</th>
              <th className="py-3 px-2 text-[10px] font-bold text-slate-400 uppercase">Due Date</th>
              <th className="py-3 px-2 text-[10px] font-bold text-slate-400 uppercase">Status</th>
              <th className="py-3 px-2 text-[10px] font-bold text-slate-400 uppercase text-right">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {invoices.slice(-15).reverse().map(inv => (
              <tr key={inv.id}>
                <td className="py-3 px-2 font-bold text-xs">{inv.invoiceNumber}</td>
                <td className="py-3 px-2 font-medium text-xs">{inv.clientName}</td>
                <td className="py-3 px-2 text-slate-500 text-[11px]">{inv.dueDate}</td>
                <td className="py-3 px-2">
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    inv.status === 'Paid' ? 'bg-green-100 text-green-700' :
                    inv.status === 'Pending' ? 'bg-orange-100 text-orange-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {inv.status}
                  </span>
                </td>
                <td className="py-3 px-2 text-right font-black text-xs">{user.currency}{inv.totalAmount.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-auto border-t border-slate-100 pt-8 text-center opacity-50">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em]">Business Analytics Performance Summary</p>
          <p className="text-[8px] mt-1 italic">This report is automatically generated by InvoicePlus and represents current ledger status.</p>
        </div>
      </div>

      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>
          <p className="text-slate-500 mt-1">Welcome back, {user.name}. Here's what's happening today.</p>
        </div>
        <div className="flex space-x-3 print:hidden no-print">
          <button 
            onClick={handleDownloadReport}
            disabled={isGeneratingReport}
            className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-all font-medium text-sm flex items-center space-x-2 shadow-sm disabled:opacity-50"
          >
            {isGeneratingReport ? <Loader2 size={18} className="animate-spin text-blue-600" /> : <BarChart3 size={18} className="text-blue-600" />}
            <span>{isGeneratingReport ? 'Generating...' : 'Download Design Report'}</span>
          </button>
          <button 
            onClick={onCreateInvoice}
            className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all font-medium text-sm flex items-center space-x-2 shadow-lg shadow-blue-200"
          >
            <Plus size={18} />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <SummaryCard 
          title="Total Invoices" 
          value={stats.totalInvoices} 
          icon={<FileText size={22} />} 
          color="bg-blue-600" 
          trend="Total volume"
        />
        <SummaryCard 
          title="Pending" 
          value={formatCurrency(stats.pendingAmount)} 
          subtitle={`${stats.pendingCount} invoices`}
          icon={<Clock size={22} />} 
          color="bg-orange-500" 
          trend="Awaiting payment"
        />
        <SummaryCard 
          title="Paid" 
          value={formatCurrency(stats.paidAmount)} 
          subtitle={`${stats.paidCount} invoices`}
          icon={<CheckCircle size={22} />} 
          color="bg-green-500" 
          trend="Successfully collected"
        />
        <SummaryCard 
          title="Overdue" 
          value={formatCurrency(stats.overdueAmount)} 
          subtitle={`${stats.overdueCount} invoices`}
          icon={<AlertCircle size={22} />} 
          color="bg-red-500" 
          trend="Requires attention"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Revenue Overview</h3>
              <p className="text-sm text-slate-500">Real-time billing performance</p>
            </div>
            <div className="flex items-center space-x-4 print:hidden no-print">
               <div className="flex items-center space-x-1.5">
                  <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Total Billed</span>
               </div>
               <div className="flex items-center space-x-1.5">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Actually Paid</span>
               </div>
            </div>
          </div>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyRevenueData}>
                <defs>
                  <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} tickFormatter={(v) => `${user.currency}${v >= 1000 ? (v/1000).toFixed(0) + 'k' : v}`} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number, name: string) => [formatCurrency(value), name === 'amount' ? 'Total Billed' : 'Collected (Paid)']}
                />
                <Area type="monotone" dataKey="amount" stroke="#2563EB" strokeWidth={3} fillOpacity={1} fill="url(#colorAmt)" name="amount" />
                <Area type="monotone" dataKey="paid" stroke="#10B981" strokeWidth={2} strokeDasharray="5 5" fill="none" name="paid" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-8 flex items-center justify-between pt-6 border-t border-slate-100">
            <div className="flex space-x-12">
              <div>
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">This Month</p>
                <h4 className="text-xl font-bold text-slate-900 mt-1">{formatCurrency(currentMonthTotal)}</h4>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">Total Revenue</p>
                <h4 className="text-xl font-bold text-slate-900 mt-1">{formatCurrency(stats.paidAmount + stats.pendingAmount)}</h4>
              </div>
            </div>
            {invoices.length > 0 && (
              <div className="flex items-center space-x-2 text-blue-600 bg-blue-50 px-3 py-1 rounded-full text-sm font-bold">
                <TrendingUp size={16} />
                <span>Live Data</span>
              </div>
            )}
          </div>
        </div>

        {/* Status Distribution Donut Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-lg font-bold text-slate-900 mb-2">Invoice Status</h3>
          <p className="text-sm text-slate-500 mb-8">Breakdown of current pipeline</p>
          
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="h-64 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={clientData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {clientData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => [`${value} Invoices`, 'Count']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-3xl font-bold text-slate-900">{stats.totalInvoices}</span>
                <span className="text-sm text-slate-500 font-medium">Total</span>
              </div>
            </div>

            <div className="w-full space-y-3 mt-6">
              {clientData.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{backgroundColor: item.color}}></div>
                    <span className="text-sm text-slate-600 font-medium">{item.name}</span>
                  </div>
                  <span className="text-sm font-bold text-slate-900">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Invoices Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-900">Recent Invoices</h3>
            <button 
              onClick={onViewAllInvoices}
              className="text-blue-600 hover:text-blue-700 text-sm font-bold print:hidden no-print"
            >
              View All
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-400 text-xs font-bold uppercase tracking-wider">
                  <th className="px-6 py-4">Invoice ID</th>
                  <th className="px-6 py-4">Client</th>
                  <th className="px-6 py-4">Due Date</th>
                  <th className="px-6 py-4">Amount</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-center print:hidden no-print">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-400 text-sm italic">
                      No invoices created yet.
                    </td>
                  </tr>
                ) : (
                  invoices.slice(-5).reverse().map((inv) => (
                    <tr 
                      key={inv.id} 
                      className="hover:bg-slate-50 transition-colors group"
                    >
                      <td 
                        className="px-6 py-4 font-bold text-slate-900 text-sm cursor-pointer hover:text-blue-600"
                        onClick={() => onViewInvoice(inv.id)}
                      >
                        {inv.invoiceNumber}
                      </td>
                      <td className="px-6 py-4 text-slate-600 text-sm font-medium">{inv.clientName}</td>
                      <td className="px-6 py-4 text-slate-500 text-sm">{new Date(inv.dueDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                      <td className="px-6 py-4 font-bold text-slate-900 text-sm">{formatCurrency(inv.totalAmount)}</td>
                      <td className="px-6 py-4">
                        <div className="relative group/status">
                          <select 
                            value={inv.status}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => onStatusChange(e, inv.id)}
                            className={`appearance-none px-3 pr-8 py-1.5 rounded-full text-[10px] md:text-xs font-bold cursor-pointer outline-none border-none transition-all shadow-sm ${
                              inv.status === 'Paid' ? 'bg-green-100 text-green-700' : 
                              inv.status === 'Pending' ? 'bg-orange-100 text-orange-700' : 
                              inv.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            <option value="Draft">Draft</option>
                            <option value="Pending">Pending</option>
                            <option value="Paid">Paid</option>
                            <option value="Overdue">Overdue</option>
                          </select>
                          <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-60" />
                        </div>
                      </td>
                      <td className="px-6 py-4 print:hidden no-print">
                        <div className="flex items-center justify-center space-x-2">
                          <button 
                            onClick={() => onViewInvoice(inv.id)}
                            title="Preview Invoice"
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                          >
                            <Eye size={16} />
                          </button>
                          <button 
                            onClick={() => alert(`Sending Invoice ${inv.invoiceNumber}...`)}
                            title="Send Invoice"
                            className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-xl transition-all"
                          >
                            <Send size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col print:hidden no-print">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Quick Actions</h3>
          <div className="space-y-4">
            <ActionButton 
              title="Create New Invoice" 
              desc="Draft a new billing statement" 
              icon={<Plus size={20} />}
              onClick={onCreateInvoice}
            />
            <ActionButton 
              title="Send Pending Invoices" 
              desc="Bulk send all pending" 
              icon={<Send size={20} />}
              onClick={() => alert('Sending all pending invoices...')}
            />
            <ActionButton 
              title="Export Performance Report" 
              desc="Get designed PDF statement" 
              icon={<FileDown size={20} />}
              onClick={handleDownloadReport}
            />
          </div>
          
          <div className="mt-10 p-5 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl text-white relative overflow-hidden group cursor-pointer shadow-lg shadow-blue-200">
            <div className="relative z-10">
              <h4 className="font-bold text-lg mb-1">Go Premium</h4>
              <p className="text-blue-100 text-sm mb-4">Unlock advanced reports and multi-user access.</p>
              <button className="px-4 py-2 bg-white text-blue-600 rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-blue-50 transition-all">Upgrade Now</button>
            </div>
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:scale-110 transition-transform">
              <TrendingUp size={80} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SummaryCard = ({ title, value, subtitle, icon, color, trend }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
    <div className="flex justify-between items-start mb-4">
      <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center text-white shadow-lg shadow-slate-100 group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <span className="text-xs font-bold text-slate-400 group-hover:text-slate-500 transition-colors uppercase tracking-wider">{title}</span>
    </div>
    <div>
      <h2 className="text-2xl font-bold text-slate-900">{value}</h2>
      {subtitle && <p className="text-xs text-slate-500 mt-1 font-medium">{subtitle}</p>}
      <p className="text-xs text-slate-400 mt-4 flex items-center">
        <TrendingUp size={12} className="mr-1 text-blue-500" />
        {trend}
      </p>
    </div>
  </div>
);

const ActionButton = ({ title, desc, icon, onClick }: any) => (
  <button 
    onClick={onClick}
    className="w-full flex items-center space-x-4 p-4 rounded-2xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/50 transition-all group text-left"
  >
    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-all">
      {icon}
    </div>
    <div>
      <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors">{title}</h4>
      <p className="text-xs text-slate-500">{desc}</p>
    </div>
  </button>
);

export default Dashboard;
